document.addEventListener("DOMContentLoaded", () => {
  const slides = document.querySelectorAll(".slideshow img");
  let currentSlide = 0;

  slideslength = slides.length;
  console.log(slideslength);

  function showNextSlide() {
    slides[currentSlide].classList.remove("active");

    currentSlide = (currentSlide + 1) % slides.length;

    slides[currentSlide].classList.add("active");
  }

  setInterval(showNextSlide, 3000);
});